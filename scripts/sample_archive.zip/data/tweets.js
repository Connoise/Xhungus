window.YTD.tweets.part0 = [
  {
    "tweet": {
      "id_str": "1234567890",
      "id": 1234567890,
      "created_at": "Mon Jan 15 12:30:00 +0000 2024",
      "full_text": "This is my first sample tweet! Testing the Xhungus parser. #testing",
      "conversation_id_str": "1234567890",
      "lang": "en",
      "entities": {
        "hashtags": [
          {
            "text": "testing"
          }
        ],
        "user_mentions": [],
        "urls": []
      }
    }
  },
  {
    "tweet": {
      "id_str": "1234567891",
      "id": 1234567891,
      "created_at": "Tue Jan 16 14:45:00 +0000 2024",
      "full_text": "Second tweet with a mention @someone and a link https://example.com",
      "conversation_id_str": "1234567891",
      "lang": "en",
      "entities": {
        "hashtags": [],
        "user_mentions": [
          {
            "screen_name": "someone"
          }
        ],
        "urls": [
          {
            "url": "https://t.co/xyz",
            "expanded_url": "https://example.com"
          }
        ]
      }
    }
  },
  {
    "tweet": {
      "id_str": "1234567892",
      "id": 1234567892,
      "created_at": "Wed Jan 17 09:15:00 +0000 2024",
      "full_text": "A reply tweet testing threading",
      "conversation_id_str": "1234567890",
      "in_reply_to_status_id_str": "1234567890",
      "lang": "en",
      "entities": {
        "hashtags": [],
        "user_mentions": [],
        "urls": []
      }
    }
  }
]