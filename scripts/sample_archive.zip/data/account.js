window.YTD.account.part0 = [
  {
    "account": {
      "username": "testuser",
      "accountId": "123456",
      "createdAt": "2020-01-01T00:00:00.000Z"
    }
  }
]